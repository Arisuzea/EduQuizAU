<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" type="text/css" href="/eduquiz/CSS/Signup.css" />
    <link
      rel="shortcut icon"
      href="/IMAGE/OfficialLogo.svg"
      type="image/x-icon"
    />
    <link
      href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css"
      rel="stylesheet"
    />
    <title>Signup</title>
  </head>
  <body>
    <!-- BRAIN IMAGE -->
    <div class="ImageBrain">
      <img
      src="/EDUQUIZ/IMAGE/utak.svg"
      alt="Brain"
      />
    </div>
    <!-- HEADER -->
    <div class="header">
      <!-- LOGO -->
      <div class="logo">
        <img
          src="https://scontent.fmnl17-2.fna.fbcdn.net/v/t1.15752-9/416254564_229762756884500_5050083700608708339_n.png?_nc_cat=111&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEMt8jjZTEtn_GreL2TVYG8S7TkXl5c5JZLtOReXlzklhk0dDkNwv--04WqKhenVzWebcEiajVdeM3ne_fAydVy&_nc_ohc=xzyIF9bMFIsAX8glpad&_nc_ht=scontent.fmnl17-2.fna&oh=03_AdRnOnQCI-m0LKBRI9H5qa-7faUDG4tmAqMRE2Hh4GUBDQ&oe=6618879E"
          alt="Logo"
        />
        <h2>EduQuiz</h2>
      </div>
      <span class="heading">
        <h1>Create an Account</h1>
      </span>
    </div>
    <div class="containerForm">
      <form action="#" method="post" id="form">
        <div class="fullname">
          <span class="firstname">
            <!-- FIRST NAME -->
            <label for="firstname">First Name</label>
            <input type="text" id="firstname" name="firstname" required />
          </span>
          <!-- LAST NAME -->
          <span class="lastname">
            <label for="lastname">Last Name</label>
            <input type="text" id="lastname" name="lastname" required />
          </span>
        </div>
        <!-- EMAIL -->
        <div class="email_address">
          <label for="email">Email Address</label>
          <input type="email" id="email" name="email" required />
        </div>

        <!-- PASSWORD -->
        <div class="Password">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" required />
        </div>

        <!-- REPEAT-PASSWORD -->
        <div class="RepeatPassword">
          <label for="RepeatPassword">Repeat Password</label>
          <input
            type="password"
            id="repeatpassword"
            name="repeatpassword"
            required
          />
        </div>
        <div class="btn-signup">
          <button type="submit" name="signup" id="submit">Sign Up</button>
        </div>
          </span>


      </form>
    </div>
    <!-- SHOW PASSWORD JS SCRIPT-->
    <!-- <script>
      function myFunction() {
        var x = document.getElementById("password");
        var y = document.getElementById("hide1");
        var z = document.getElementById("hide2");

        if (x.type === "password") {
          x.type = "text";
          y.style.display = "block";
          z.style.display = "none";
        } else {
          x.type = "password";
          y.style.display = "none";
          z.style.display = "block";
        }
      }
    </script> -->
<!-- SHOW PASSWORD -->
          <!-- <span class="showPass" onclick="myFunction()" title="Show Password">
            <i id="hide1" class="fa fa-eye"></i>
            <i id="hide2" class="fa fa-eye-slash"></i>
          </span> -->
  </body>
</html>
